package com.resource.ws.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.resource.ws.vo.VOUsuario;

@Path("/resource")
public class ServiceLoginJR {
	
	@POST
	@Path("/validaUsuario")
	@Consumes({MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_JSON})
	public VOUsuario validaUsuario(VOUsuario vo) {
		vo.setValida(false);
		if(vo.getUsuario().equals("JR") && vo.getSenha().equals("123")) {
			vo.setValida(true);
		}
		return vo;
	}
}
